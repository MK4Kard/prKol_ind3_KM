﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prKol_ind3_1_KM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            LoadData();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private Address new_address = new Address();
        private void LoadData() // вызов загрузки данных
        {
            MessageBox.Show($"Путь к файлу: {new_address.filePath}");
            new_address.LoadFromFile();
            UpdateListBox();
        }

        private void button1_Click(object sender, EventArgs e) // добавление адреса
        {
            var address = new PostalAddress(
                AddrName.Text,
                Street.Text,
                City.Text,
                Code.Text,
                Number.Text,
                Mail.Text
                );

            new_address.AddAddress(address);
            UpdateListBox();
        }
        private void UpdateListBox() // обновление лист бокса
        {
            listBox1.Items.Clear();
            foreach (PostalAddress address in new_address.AllAddress())
            {
                listBox1.Items.Add(address.ToString());
            }
        }

        private void button2_Click(object sender, EventArgs e) // удаление адреса
        {
            string name = RemoveName.Text;
            new_address.RemoveAddress(name);
            UpdateListBox();
        }

        private void button3_Click(object sender, EventArgs e) // поиск адреса
        {
            string name_upd = textBox1.Text;

            var addrFound = new_address.Find(name_upd);

            if (addrFound != null)
            {
                MessageBox.Show($"Адрес найден: {addrFound}");
            }
            else
            {
                MessageBox.Show($"Адрес не найден");
            }
        }

        private void button4_Click(object sender, EventArgs e) // изменение сатей адреса
        {
            string name_upd = AddrName.Text;

            var addrUpdate = new_address.Find(name_upd);

            if (addrUpdate != null)
            {
                addrUpdate.UpdateAddress(
                    street: Street.Text == "" ? null : Street.Text,
                    city: City.Text == "" ? null : City.Text,
                    postalCode: Code.Text == "" ? null : Code.Text,
                    number: Number.Text == "" ? null : Number.Text,
                    mail: Mail.Text == "" ? null : Mail.Text
                    );
                UpdateListBox();
                MessageBox.Show("Адрес обновлен");
            }
            else
            {
                MessageBox.Show("Адрес не найден");
            }
        }

        private void button5_Click(object sender, EventArgs e) // выгружить из файла
        {
            string fileName = textBox3.Text;
            new_address.NameFile(fileName);
            LoadData();
        }

        private void button6_Click(object sender, EventArgs e) // загружить в файл
        {
            new_address.SaveToFile(textBox2.Text);
        }
    }
}
