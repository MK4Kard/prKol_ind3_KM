﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prKol_ind3_1_KM
{
    internal class PostalAddress
    {
        public string name { get; set; }
        public string street { get; set; }
        public string city { get; set; }
        public string postalCode { get; set; }
        public string number { get; set; }
        public string mail { get; set; }

        public PostalAddress(string name, string street, string city, string postalCode, string number, string mail)
        {
            this.name = name;
            this.street = street;
            this.city = city;
            this.postalCode = postalCode;
            this.number = number;
            this.mail = mail;
        }
        // изменение составных частей адреса
        public void UpdateAddress(string name = null, string street = null, string city = null, string postalCode = null, string number = null, string mail = null)
        {
            if (name != null)
                this.name = name;
            if (street != null)
                this.street = street;
            if (city != null)
                this.city = city;
            if (postalCode != null)
                this.postalCode = postalCode;
            if (number != null)
                this.number = number;
            if (mail != null)
                this.mail = mail;
        }
        // порядок записи данных
        public override string ToString()
        {
            return $"{name}, {street}, {city}, {postalCode}, {number}, {mail}";
        }
    }
}
