﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace prKol_ind3_1_KM
{
    internal class Address
    {
        private ArrayList addresses = new ArrayList();
        public string filePath = "Docs.txt";

        public void NameFile(string fileName)
        {
            filePath = fileName;
        }

        public void AddAddress(PostalAddress address)
        {
            addresses.Add(address);
        }

        public void RemoveAddress(string name)
        {
            var addressRemove = addresses.Cast<PostalAddress>().FirstOrDefault(addr => addr.name == name);
            if (addressRemove != null)
            {
                addresses.Remove(addressRemove);
            }
        }

        public PostalAddress Find(string name)
        {
            return addresses.Cast<PostalAddress>().FirstOrDefault(addr => addr.name == name);
        }

        public ArrayList AllAddress()
        {
            return addresses;
        }

        public void LoadFromFile()
        {
            if (File.Exists(filePath))
            {
                try
                {
                    var lines = File.ReadAllLines(filePath);
                    MessageBox.Show($"Прочитано строк: {lines.Length}");
                    foreach (var line in lines)
                    {
                        var parts = line.Split(',');
                        if (parts.Length == 6)
                        {
                            var address = new PostalAddress(
                                parts[0], // name
                                parts[1], // street
                                parts[2], // city
                                parts[3], // postalCode
                                parts[4], // number
                                parts[5]  // mail
                            );
                            addresses.Add(address);
                            MessageBox.Show($"Добавлен адрес: {address}");
                        }
                        else
                        {
                            MessageBox.Show($"Некорректная строка в файле: {line}");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при чтении файла: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Файл не найден!");
            }
        }

        public void SaveToFile()
        {
            if (!string.IsNullOrEmpty(filePath))
            {
                var lines = addresses.Cast<PostalAddress>()
                    .Select(addr => $"{addr.name},{addr.street},{addr.city},{addr.postalCode},{addr.number},{addr.mail}");
                File.WriteAllLines(filePath, lines);
            }
        }
        public void SaveToFile(string name)
        {
            if (!string.IsNullOrEmpty(filePath))
            {
                var lines = addresses.Cast<PostalAddress>()
                    .Select(addr => $"{addr.name},{addr.street},{addr.city},{addr.postalCode},{addr.number},{addr.mail}");
                File.WriteAllLines(name, lines);
            }
        }
    }
}
